export class ProductList{

    productId: number;
  productName: string;
  productQuantity: number;

    constructor(productName,productQuantity){
        this.productId = productName;
        this.productName =productQuantity;
        
    }
}