export class ProductList{
    productName: string;
    quantity: string;
    
    constructor(productName,quantity){
        this.productName = productName;
        this.quantity = quantity;
        
    }
}