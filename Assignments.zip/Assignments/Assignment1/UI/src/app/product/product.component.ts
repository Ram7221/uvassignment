import { Component, OnInit } from '@angular/core';
import { ProductList } from './ProductList'
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit{
  productList: Array<ProductList>;
  isBtnEnabled: boolean=false;
  constructor(){
      this.productList = [];
  }
  ngOnInit() {
      this.productList=[
          {productName:'Moto G5',quantity:'2'},
          {productName:'Racold Geyser',quantity:'3'},
          {productName:'Dell Inspiron Laptop',quantity:'1'},
      ]
  }
  addProduct(productName,quantity){
      let product = new ProductList(productName,quantity);
      this.productList.push(product);
      this.isBtnEnabled=true;

  }
}
